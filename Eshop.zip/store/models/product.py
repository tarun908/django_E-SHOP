from django.db import models


class Product(models.Model):
    objects = None
    Name = models.CharField(max_length=30)
    MRP = models.DecimalField(max_digits=10, decimal_places=2)
    Categore = models.ForeignKey('Categore', on_delete=models.CASCADE, default=2)
    Description = models.CharField(max_length=300, default='', null=True, blank=True)
    Image = models.ImageField(upload_to='uploads/products/')

    @staticmethod
    def get_products_by_id(ids):
        return Product.objects.filter(id__in=ids)

    @staticmethod
    def get_all_products():
        return Product.objects.all()

    @staticmethod
    def get_all_products_by_categoreid(categore_id):
        if categore_id:
            return Product.objects.filter(Categore=categore_id)
        else:
            return Product.get_all_products();

from django.shortcuts import render, redirect
from django.contrib.auth.hashers import make_password
from store.models.customer import Customer
from django.views import View


class signup(View):
    @staticmethod
    def get(request):
        return render(request, 'signup.html')

    def post(self, request):
        postData = request.POST
        firstname = postData.get('firstname')
        lastname = postData.get('lastname')
        phone = postData.get('phone')
        email = postData.get('email')
        password = postData.get('password')

        # validation
        value = {
            'firstname': firstname,
            'lastname': lastname,
            'phone': phone,
            'email': email
        }
        error_message = None

        customer = Customer(firstname=firstname,
                            lastname=lastname,
                            phone=phone,
                            email=email,
                            password=password)
        error_message = validateCustomer(customer)

        if not error_message:
            print(firstname, lastname, phone, email, password)
            customer.password = make_password(customer.password)

            customer.register()
            return redirect('homepage')
        else:
            data = {
                'error': error_message,
                'values': value
            }
            return render(request, 'signup.html', data)


def validateCustomer(customer):
    error_message = None
    if not customer.firstname:
        error_message = "First Name Required"
    elif len(customer.firstname) < 4:
        error_message = " First Name Must Be 4 Char Long or more"
    elif not customer.lastname:
        error_message = "Last Name Required"
    elif len(customer.lastname) < 4:
        error_message = " Last Name Must Be 4 Char Long or more"
    elif not customer.phone:
        error_message = "Phone No Required"
    elif len(customer.phone) < 10:
        error_message = " Phone No Must Be 10 Char Long or more"
    elif not customer.email:
        error_message = "email Required"
    elif len(customer.email) < 4:
        error_message = " email  Must Be 4 Char Long or more"
    elif not customer.password:
        error_message = "Password Required"
    elif len(customer.password) < 4:
        error_message = " Password  Must Be 5 Char Long or more"
    elif customer.isExists():

        error_message = 'Email Address Already Register'
    # saving
    return error_message

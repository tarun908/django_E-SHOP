from django.contrib import admin
from .models.product import Product
from .models.categore import Categore
from .models.customer import Customer
from .models.orders import Order


class Adminproduct(admin.ModelAdmin):
    list_display = ['Name', 'MRP', 'Categore']



class AdminCategore(admin.ModelAdmin):
    list_display = ['name']


# Register your models here.
admin.site.register(Product , Adminproduct)
admin.site.register(Categore, AdminCategore)
admin.site.register(Customer)
admin.site.register(Order)


